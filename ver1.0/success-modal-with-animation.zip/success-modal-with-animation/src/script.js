$(document).ready(function() {
		$('.redo').click(function() {
			$('.success, .error').toggle();
		});
});