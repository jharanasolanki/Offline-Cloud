<?php

namespace movemegif\exception;

use \Exception;

/**
 * @author Patrick van Bergen
 */
class MovemegifException extends Exception
{

}