<?php

namespace movemegif\data;

/**
 * @author Patrick van Bergen
 */
class HeaderBlock
{
    public function getContents()
    {
        return "GIF89a";
    }
}